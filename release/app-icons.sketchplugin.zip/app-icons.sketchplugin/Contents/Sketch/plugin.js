var process=typeof process==="undefined"?{listenerCount:function(){return 0},emit:function(){}}:process;
"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// node_modules/events/events.js
var require_events = __commonJS({
  "node_modules/events/events.js"(exports2, module2) {
    "use strict";
    var R = typeof Reflect === "object" ? Reflect : null;
    var ReflectApply = R && typeof R.apply === "function" ? R.apply : function ReflectApply2(target, receiver, args2) {
      return Function.prototype.apply.call(target, receiver, args2);
    };
    var ReflectOwnKeys;
    if (R && typeof R.ownKeys === "function") {
      ReflectOwnKeys = R.ownKeys;
    } else if (Object.getOwnPropertySymbols) {
      ReflectOwnKeys = function ReflectOwnKeys2(target) {
        return Object.getOwnPropertyNames(target).concat(Object.getOwnPropertySymbols(target));
      };
    } else {
      ReflectOwnKeys = function ReflectOwnKeys2(target) {
        return Object.getOwnPropertyNames(target);
      };
    }
    function ProcessEmitWarning(warning) {
      if (console && console.warn) console.warn(warning);
    }
    var NumberIsNaN = Number.isNaN || function NumberIsNaN2(value) {
      return value !== value;
    };
    function EventEmitter() {
      EventEmitter.init.call(this);
    }
    module2.exports = EventEmitter;
    module2.exports.once = once;
    EventEmitter.EventEmitter = EventEmitter;
    EventEmitter.prototype._events = void 0;
    EventEmitter.prototype._eventsCount = 0;
    EventEmitter.prototype._maxListeners = void 0;
    var defaultMaxListeners = 10;
    function checkListener(listener) {
      if (typeof listener !== "function") {
        throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
      }
    }
    Object.defineProperty(EventEmitter, "defaultMaxListeners", {
      enumerable: true,
      get: function() {
        return defaultMaxListeners;
      },
      set: function(arg) {
        if (typeof arg !== "number" || arg < 0 || NumberIsNaN(arg)) {
          throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + ".");
        }
        defaultMaxListeners = arg;
      }
    });
    EventEmitter.init = function() {
      if (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) {
        this._events = /* @__PURE__ */ Object.create(null);
        this._eventsCount = 0;
      }
      this._maxListeners = this._maxListeners || void 0;
    };
    EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
      if (typeof n !== "number" || n < 0 || NumberIsNaN(n)) {
        throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + n + ".");
      }
      this._maxListeners = n;
      return this;
    };
    function _getMaxListeners(that) {
      if (that._maxListeners === void 0)
        return EventEmitter.defaultMaxListeners;
      return that._maxListeners;
    }
    EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
      return _getMaxListeners(this);
    };
    EventEmitter.prototype.emit = function emit(type) {
      var args2 = [];
      for (var i = 1; i < arguments.length; i++) args2.push(arguments[i]);
      var doError = type === "error";
      var events = this._events;
      if (events !== void 0)
        doError = doError && events.error === void 0;
      else if (!doError)
        return false;
      if (doError) {
        var er;
        if (args2.length > 0)
          er = args2[0];
        if (er instanceof Error) {
          throw er;
        }
        var err = new Error("Unhandled error." + (er ? " (" + er.message + ")" : ""));
        err.context = er;
        throw err;
      }
      var handler = events[type];
      if (handler === void 0)
        return false;
      if (typeof handler === "function") {
        ReflectApply(handler, this, args2);
      } else {
        var len = handler.length;
        var listeners = arrayClone(handler, len);
        for (var i = 0; i < len; ++i)
          ReflectApply(listeners[i], this, args2);
      }
      return true;
    };
    function _addListener(target, type, listener, prepend) {
      var m;
      var events;
      var existing;
      checkListener(listener);
      events = target._events;
      if (events === void 0) {
        events = target._events = /* @__PURE__ */ Object.create(null);
        target._eventsCount = 0;
      } else {
        if (events.newListener !== void 0) {
          target.emit(
            "newListener",
            type,
            listener.listener ? listener.listener : listener
          );
          events = target._events;
        }
        existing = events[type];
      }
      if (existing === void 0) {
        existing = events[type] = listener;
        ++target._eventsCount;
      } else {
        if (typeof existing === "function") {
          existing = events[type] = prepend ? [listener, existing] : [existing, listener];
        } else if (prepend) {
          existing.unshift(listener);
        } else {
          existing.push(listener);
        }
        m = _getMaxListeners(target);
        if (m > 0 && existing.length > m && !existing.warned) {
          existing.warned = true;
          var w = new Error("Possible EventEmitter memory leak detected. " + existing.length + " " + String(type) + " listeners added. Use emitter.setMaxListeners() to increase limit");
          w.name = "MaxListenersExceededWarning";
          w.emitter = target;
          w.type = type;
          w.count = existing.length;
          ProcessEmitWarning(w);
        }
      }
      return target;
    }
    EventEmitter.prototype.addListener = function addListener(type, listener) {
      return _addListener(this, type, listener, false);
    };
    EventEmitter.prototype.on = EventEmitter.prototype.addListener;
    EventEmitter.prototype.prependListener = function prependListener(type, listener) {
      return _addListener(this, type, listener, true);
    };
    function onceWrapper() {
      if (!this.fired) {
        this.target.removeListener(this.type, this.wrapFn);
        this.fired = true;
        if (arguments.length === 0)
          return this.listener.call(this.target);
        return this.listener.apply(this.target, arguments);
      }
    }
    function _onceWrap(target, type, listener) {
      var state = { fired: false, wrapFn: void 0, target, type, listener };
      var wrapped = onceWrapper.bind(state);
      wrapped.listener = listener;
      state.wrapFn = wrapped;
      return wrapped;
    }
    EventEmitter.prototype.once = function once2(type, listener) {
      checkListener(listener);
      this.on(type, _onceWrap(this, type, listener));
      return this;
    };
    EventEmitter.prototype.prependOnceListener = function prependOnceListener(type, listener) {
      checkListener(listener);
      this.prependListener(type, _onceWrap(this, type, listener));
      return this;
    };
    EventEmitter.prototype.removeListener = function removeListener(type, listener) {
      var list, events, position, i, originalListener;
      checkListener(listener);
      events = this._events;
      if (events === void 0)
        return this;
      list = events[type];
      if (list === void 0)
        return this;
      if (list === listener || list.listener === listener) {
        if (--this._eventsCount === 0)
          this._events = /* @__PURE__ */ Object.create(null);
        else {
          delete events[type];
          if (events.removeListener)
            this.emit("removeListener", type, list.listener || listener);
        }
      } else if (typeof list !== "function") {
        position = -1;
        for (i = list.length - 1; i >= 0; i--) {
          if (list[i] === listener || list[i].listener === listener) {
            originalListener = list[i].listener;
            position = i;
            break;
          }
        }
        if (position < 0)
          return this;
        if (position === 0)
          list.shift();
        else {
          spliceOne(list, position);
        }
        if (list.length === 1)
          events[type] = list[0];
        if (events.removeListener !== void 0)
          this.emit("removeListener", type, originalListener || listener);
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(type) {
      var listeners, events, i;
      events = this._events;
      if (events === void 0)
        return this;
      if (events.removeListener === void 0) {
        if (arguments.length === 0) {
          this._events = /* @__PURE__ */ Object.create(null);
          this._eventsCount = 0;
        } else if (events[type] !== void 0) {
          if (--this._eventsCount === 0)
            this._events = /* @__PURE__ */ Object.create(null);
          else
            delete events[type];
        }
        return this;
      }
      if (arguments.length === 0) {
        var keys = Object.keys(events);
        var key;
        for (i = 0; i < keys.length; ++i) {
          key = keys[i];
          if (key === "removeListener") continue;
          this.removeAllListeners(key);
        }
        this.removeAllListeners("removeListener");
        this._events = /* @__PURE__ */ Object.create(null);
        this._eventsCount = 0;
        return this;
      }
      listeners = events[type];
      if (typeof listeners === "function") {
        this.removeListener(type, listeners);
      } else if (listeners !== void 0) {
        for (i = listeners.length - 1; i >= 0; i--) {
          this.removeListener(type, listeners[i]);
        }
      }
      return this;
    };
    function _listeners(target, type, unwrap) {
      var events = target._events;
      if (events === void 0)
        return [];
      var evlistener = events[type];
      if (evlistener === void 0)
        return [];
      if (typeof evlistener === "function")
        return unwrap ? [evlistener.listener || evlistener] : [evlistener];
      return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
    }
    EventEmitter.prototype.listeners = function listeners(type) {
      return _listeners(this, type, true);
    };
    EventEmitter.prototype.rawListeners = function rawListeners(type) {
      return _listeners(this, type, false);
    };
    EventEmitter.listenerCount = function(emitter, type) {
      if (typeof emitter.listenerCount === "function") {
        return emitter.listenerCount(type);
      } else {
        return listenerCount.call(emitter, type);
      }
    };
    EventEmitter.prototype.listenerCount = listenerCount;
    function listenerCount(type) {
      var events = this._events;
      if (events !== void 0) {
        var evlistener = events[type];
        if (typeof evlistener === "function") {
          return 1;
        } else if (evlistener !== void 0) {
          return evlistener.length;
        }
      }
      return 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
    };
    function arrayClone(arr, n) {
      var copy = new Array(n);
      for (var i = 0; i < n; ++i)
        copy[i] = arr[i];
      return copy;
    }
    function spliceOne(list, index) {
      for (; index + 1 < list.length; index++)
        list[index] = list[index + 1];
      list.pop();
    }
    function unwrapListeners(arr) {
      var ret = new Array(arr.length);
      for (var i = 0; i < ret.length; ++i) {
        ret[i] = arr[i].listener || arr[i];
      }
      return ret;
    }
    function once(emitter, name) {
      return new Promise(function(resolve, reject) {
        function errorListener(err) {
          emitter.removeListener(name, resolver);
          reject(err);
        }
        function resolver() {
          if (typeof emitter.removeListener === "function") {
            emitter.removeListener("error", errorListener);
          }
          resolve([].slice.call(arguments));
        }
        ;
        eventTargetAgnosticAddListener(emitter, name, resolver, { once: true });
        if (name !== "error") {
          addErrorHandlerIfEventEmitter(emitter, errorListener, { once: true });
        }
      });
    }
    function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
      if (typeof emitter.on === "function") {
        eventTargetAgnosticAddListener(emitter, "error", handler, flags);
      }
    }
    function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
      if (typeof emitter.on === "function") {
        if (flags.once) {
          emitter.once(name, listener);
        } else {
          emitter.on(name, listener);
        }
      } else if (typeof emitter.addEventListener === "function") {
        emitter.addEventListener(name, function wrapListener(arg) {
          if (flags.once) {
            emitter.removeEventListener(name, wrapListener);
          }
          listener(arg);
        });
      } else {
        throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof emitter);
      }
    }
  }
});

// node_modules/sketch-module-web-view/lib/browser-api.js
var require_browser_api = __commonJS({
  "node_modules/sketch-module-web-view/lib/browser-api.js"(exports2, module2) {
    function parseHexColor(color) {
      if (!color || color[0] !== "#") {
        if (color && typeof color.isKindOfClass === "function" && color.isKindOfClass(NSColor)) {
          return color;
        }
        throw new Error(
          "Incorrect color formating. It should be an hex color: #RRGGBBAA"
        );
      }
      var source = color.substr(1);
      if (source.length === 3) {
        source += "F";
      } else if (source.length === 6) {
        source += "FF";
      }
      var hex;
      if (source.length === 4) {
        for (var i = 0; i < 4; i += 1) {
          hex += source[i];
          hex += source[i];
        }
      } else if (source.length === 8) {
        hex = source;
      } else {
        return NSColor.whiteColor();
      }
      var r = parseInt(hex.slice(0, 2), 16) / 255;
      var g = parseInt(hex.slice(2, 4), 16) / 255;
      var b = parseInt(hex.slice(4, 6), 16) / 255;
      var a = parseInt(hex.slice(6, 8), 16) / 255;
      return NSColor.colorWithSRGBRed_green_blue_alpha(r, g, b, a);
    }
    module2.exports = function(browserWindow2, panel, webview) {
      browserWindow2._panel = panel;
      browserWindow2._webview = webview;
      browserWindow2._destroyed = false;
      browserWindow2.destroy = function() {
        return panel.close();
      };
      browserWindow2.close = function() {
        if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
          var shouldClose = true;
          browserWindow2.emit("close", {
            get defaultPrevented() {
              return !shouldClose;
            },
            preventDefault: function() {
              shouldClose = false;
            }
          });
          if (shouldClose) {
            panel.delegate().utils.parentWindow.endSheet(panel);
          }
          return;
        }
        if (!browserWindow2.isClosable()) {
          return;
        }
        panel.performClose(null);
      };
      function focus(focused) {
        if (!browserWindow2.isVisible()) {
          return;
        }
        if (focused) {
          NSApplication.sharedApplication().activateIgnoringOtherApps(true);
          panel.makeKeyAndOrderFront(null);
        } else {
          panel.orderBack(null);
          NSApp.mainWindow().makeKeyAndOrderFront(null);
        }
      }
      browserWindow2.focus = focus.bind(this, true);
      browserWindow2.blur = focus.bind(this, false);
      browserWindow2.isFocused = function() {
        return panel.isKeyWindow();
      };
      browserWindow2.isDestroyed = function() {
        return browserWindow2._destroyed;
      };
      browserWindow2.show = function() {
        NSApp.activateIgnoringOtherApps(true);
        if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
          return panel.delegate().utils.parentWindow.beginSheet_completionHandler(
            panel,
            __mocha__.createBlock_function("v16@?0q8", function() {
              browserWindow2.emit("closed");
            })
          );
        }
        return panel.makeKeyAndOrderFront(null);
      };
      browserWindow2.showInactive = function() {
        return panel.orderFrontRegardless();
      };
      browserWindow2.hide = function() {
        return panel.orderOut(null);
      };
      browserWindow2.isVisible = function() {
        return panel.isVisible();
      };
      browserWindow2.isModal = function() {
        return false;
      };
      browserWindow2.maximize = function() {
        if (!browserWindow2.isMaximized()) {
          panel.zoom(null);
        }
      };
      browserWindow2.unmaximize = function() {
        if (browserWindow2.isMaximized()) {
          panel.zoom(null);
        }
      };
      browserWindow2.isMaximized = function() {
        if ((panel.styleMask() & NSResizableWindowMask) !== 0) {
          return panel.isZoomed();
        }
        var rectScreen = NSScreen.mainScreen().visibleFrame();
        var rectWindow = panel.frame();
        return rectScreen.origin.x == rectWindow.origin.x && rectScreen.origin.y == rectWindow.origin.y && rectScreen.size.width == rectWindow.size.width && rectScreen.size.height == rectWindow.size.height;
      };
      browserWindow2.minimize = function() {
        return panel.miniaturize(null);
      };
      browserWindow2.restore = function() {
        return panel.deminiaturize(null);
      };
      browserWindow2.isMinimized = function() {
        return panel.isMiniaturized();
      };
      browserWindow2.setFullScreen = function(fullscreen) {
        if (fullscreen !== browserWindow2.isFullscreen()) {
          panel.toggleFullScreen(null);
        }
      };
      browserWindow2.isFullscreen = function() {
        return panel.styleMask() & NSFullScreenWindowMask;
      };
      browserWindow2.setAspectRatio = function(aspectRatio) {
        if (aspectRatio > 0) {
          panel.setAspectRatio(NSMakeSize(aspectRatio, 1));
        } else {
          panel.setResizeIncrements(NSMakeSize(1, 1));
        }
      };
      browserWindow2.setBounds = function(bounds, animate) {
        if (!bounds) {
          return;
        }
        if (browserWindow2.isFullscreen()) {
          return;
        }
        const newBounds = Object.assign(browserWindow2.getBounds(), bounds);
        var cocoaBounds = NSMakeRect(
          newBounds.x,
          0,
          newBounds.width,
          newBounds.height
        );
        var screen = NSScreen.screens().firstObject();
        cocoaBounds.origin.y = NSHeight(screen.frame()) - newBounds.y;
        panel.setFrame_display_animate(cocoaBounds, true, animate);
      };
      browserWindow2.getBounds = function() {
        const cocoaBounds = panel.frame();
        var mainScreenRect = NSScreen.screens().firstObject().frame();
        return {
          x: cocoaBounds.origin.x,
          y: Math.round(NSHeight(mainScreenRect) - cocoaBounds.origin.y),
          width: cocoaBounds.size.width,
          height: cocoaBounds.size.height
        };
      };
      browserWindow2.setContentBounds = function(bounds, animate) {
        browserWindow2.setBounds(bounds, animate);
      };
      browserWindow2.getContentBounds = function() {
        return browserWindow2.getBounds();
      };
      browserWindow2.setSize = function(width, height, animate) {
        return browserWindow2.setBounds({ width, height }, animate);
      };
      browserWindow2.getSize = function() {
        var bounds = browserWindow2.getBounds();
        return [bounds.width, bounds.height];
      };
      browserWindow2.setContentSize = function(width, height, animate) {
        return browserWindow2.setContentBounds(
          { width, height },
          animate
        );
      };
      browserWindow2.getContentSize = function() {
        var bounds = browserWindow2.getContentBounds();
        return [bounds.width, bounds.height];
      };
      browserWindow2.setMinimumSize = function(width, height) {
        const minSize = CGSizeMake(width, height);
        panel.setContentMinSize(minSize);
      };
      browserWindow2.getMinimumSize = function() {
        const size = panel.contentMinSize();
        return [size.width, size.height];
      };
      browserWindow2.setMaximumSize = function(width, height) {
        const maxSize = CGSizeMake(width, height);
        panel.setContentMaxSize(maxSize);
      };
      browserWindow2.getMaximumSize = function() {
        const size = panel.contentMaxSize();
        return [size.width, size.height];
      };
      browserWindow2.setResizable = function(resizable) {
        return browserWindow2._setStyleMask(resizable, NSResizableWindowMask);
      };
      browserWindow2.isResizable = function() {
        return panel.styleMask() & NSResizableWindowMask;
      };
      browserWindow2.setMovable = function(movable) {
        return panel.setMovable(movable);
      };
      browserWindow2.isMovable = function() {
        return panel.isMovable();
      };
      browserWindow2.setMinimizable = function(minimizable) {
        return browserWindow2._setStyleMask(minimizable, NSMiniaturizableWindowMask);
      };
      browserWindow2.isMinimizable = function() {
        return panel.styleMask() & NSMiniaturizableWindowMask;
      };
      browserWindow2.setMaximizable = function(maximizable) {
        if (panel.standardWindowButton(NSWindowZoomButton)) {
          panel.standardWindowButton(NSWindowZoomButton).setEnabled(maximizable);
        }
      };
      browserWindow2.isMaximizable = function() {
        return panel.standardWindowButton(NSWindowZoomButton) && panel.standardWindowButton(NSWindowZoomButton).isEnabled();
      };
      browserWindow2.setFullScreenable = function(fullscreenable) {
        browserWindow2._setCollectionBehavior(
          fullscreenable,
          NSWindowCollectionBehaviorFullScreenPrimary
        );
        browserWindow2._setCollectionBehavior(
          !fullscreenable,
          NSWindowCollectionBehaviorFullScreenAuxiliary
        );
      };
      browserWindow2.isFullScreenable = function() {
        var collectionBehavior = panel.collectionBehavior();
        return collectionBehavior & NSWindowCollectionBehaviorFullScreenPrimary;
      };
      browserWindow2.setClosable = function(closable) {
        browserWindow2._setStyleMask(closable, NSClosableWindowMask);
      };
      browserWindow2.isClosable = function() {
        return panel.styleMask() & NSClosableWindowMask;
      };
      browserWindow2.setAlwaysOnTop = function(top, level, relativeLevel) {
        var windowLevel = NSNormalWindowLevel;
        var maxWindowLevel = CGWindowLevelForKey(kCGMaximumWindowLevelKey);
        var minWindowLevel = CGWindowLevelForKey(kCGMinimumWindowLevelKey);
        if (top) {
          if (level === "normal") {
            windowLevel = NSNormalWindowLevel;
          } else if (level === "torn-off-menu") {
            windowLevel = NSTornOffMenuWindowLevel;
          } else if (level === "modal-panel") {
            windowLevel = NSModalPanelWindowLevel;
          } else if (level === "main-menu") {
            windowLevel = NSMainMenuWindowLevel;
          } else if (level === "status") {
            windowLevel = NSStatusWindowLevel;
          } else if (level === "pop-up-menu") {
            windowLevel = NSPopUpMenuWindowLevel;
          } else if (level === "screen-saver") {
            windowLevel = NSScreenSaverWindowLevel;
          } else if (level === "dock") {
            windowLevel = NSDockWindowLevel;
          } else {
            windowLevel = NSFloatingWindowLevel;
          }
        }
        var newLevel = windowLevel + (relativeLevel || 0);
        if (newLevel >= minWindowLevel && newLevel <= maxWindowLevel) {
          panel.setLevel(newLevel);
        } else {
          throw new Error(
            "relativeLevel must be between " + minWindowLevel + " and " + maxWindowLevel
          );
        }
      };
      browserWindow2.isAlwaysOnTop = function() {
        return panel.level() !== NSNormalWindowLevel;
      };
      browserWindow2.moveTop = function() {
        return panel.orderFrontRegardless();
      };
      browserWindow2.center = function() {
        panel.center();
      };
      browserWindow2.setPosition = function(x, y, animate) {
        return browserWindow2.setBounds({ x, y }, animate);
      };
      browserWindow2.getPosition = function() {
        var bounds = browserWindow2.getBounds();
        return [bounds.x, bounds.y];
      };
      browserWindow2.setTitle = function(title) {
        panel.setTitle(title);
      };
      browserWindow2.getTitle = function() {
        return String(panel.title());
      };
      var attentionRequestId = 0;
      browserWindow2.flashFrame = function(flash) {
        if (flash) {
          attentionRequestId = NSApp.requestUserAttention(NSInformationalRequest);
        } else {
          NSApp.cancelUserAttentionRequest(attentionRequestId);
          attentionRequestId = 0;
        }
      };
      browserWindow2.getNativeWindowHandle = function() {
        return panel;
      };
      browserWindow2.getNativeWebViewHandle = function() {
        return webview;
      };
      browserWindow2.loadURL = function(url) {
        if (/^(?!https?|file).*\.html?$/.test(url)) {
          if (typeof __command !== "undefined" && __command.pluginBundle()) {
            url = "file://" + __command.pluginBundle().urlForResourceNamed(url).path();
          }
        }
        if (/^file:\/\/.*\.html?$/.test(url)) {
          url = NSString.alloc().initWithString(url);
          url = url.stringByAddingPercentEncodingWithAllowedCharacters(
            NSCharacterSet.URLQueryAllowedCharacterSet()
          );
          webview.loadFileURL_allowingReadAccessToURL(
            NSURL.URLWithString(url),
            NSURL.URLWithString("file:///")
          );
          return;
        }
        const properURL = NSURL.URLWithString(url);
        const urlRequest = NSURLRequest.requestWithURL(properURL);
        webview.loadRequest(urlRequest);
      };
      browserWindow2.reload = function() {
        webview.reload();
      };
      browserWindow2.setHasShadow = function(hasShadow) {
        return panel.setHasShadow(hasShadow);
      };
      browserWindow2.hasShadow = function() {
        return panel.hasShadow();
      };
      browserWindow2.setOpacity = function(opacity) {
        return panel.setAlphaValue(opacity);
      };
      browserWindow2.getOpacity = function() {
        return panel.alphaValue();
      };
      browserWindow2.setVisibleOnAllWorkspaces = function(visible) {
        return browserWindow2._setCollectionBehavior(
          visible,
          NSWindowCollectionBehaviorCanJoinAllSpaces
        );
      };
      browserWindow2.isVisibleOnAllWorkspaces = function() {
        var collectionBehavior = panel.collectionBehavior();
        return collectionBehavior & NSWindowCollectionBehaviorCanJoinAllSpaces;
      };
      browserWindow2.setIgnoreMouseEvents = function(ignore) {
        return panel.setIgnoresMouseEvents(ignore);
      };
      browserWindow2.setContentProtection = function(enable) {
        panel.setSharingType(enable ? NSWindowSharingNone : NSWindowSharingReadOnly);
      };
      browserWindow2.setAutoHideCursor = function(autoHide) {
        panel.setDisableAutoHideCursor(autoHide);
      };
      browserWindow2.setVibrancy = function(type) {
        var effectView = browserWindow2._vibrantView;
        if (!type) {
          if (effectView == null) {
            return;
          }
          effectView.removeFromSuperview();
          panel.setVibrantView(null);
          return;
        }
        if (effectView == null) {
          var contentView = panel.contentView();
          effectView = NSVisualEffectView.alloc().initWithFrame(
            contentView.bounds()
          );
          browserWindow2._vibrantView = effectView;
          effectView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable);
          effectView.setBlendingMode(NSVisualEffectBlendingModeBehindWindow);
          effectView.setState(NSVisualEffectStateActive);
          effectView.setFrame(contentView.bounds());
          contentView.addSubview_positioned_relativeTo(
            effectView,
            NSWindowBelow,
            null
          );
        }
        var vibrancyType = NSVisualEffectMaterialLight;
        if (type === "appearance-based") {
          vibrancyType = NSVisualEffectMaterialAppearanceBased;
        } else if (type === "light") {
          vibrancyType = NSVisualEffectMaterialLight;
        } else if (type === "dark") {
          vibrancyType = NSVisualEffectMaterialDark;
        } else if (type === "titlebar") {
          vibrancyType = NSVisualEffectMaterialTitlebar;
        } else if (type === "selection") {
          vibrancyType = NSVisualEffectMaterialSelection;
        } else if (type === "menu") {
          vibrancyType = NSVisualEffectMaterialMenu;
        } else if (type === "popover") {
          vibrancyType = NSVisualEffectMaterialPopover;
        } else if (type === "sidebar") {
          vibrancyType = NSVisualEffectMaterialSidebar;
        } else if (type === "medium-light") {
          vibrancyType = NSVisualEffectMaterialMediumLight;
        } else if (type === "ultra-dark") {
          vibrancyType = NSVisualEffectMaterialUltraDark;
        }
        effectView.setMaterial(vibrancyType);
      };
      browserWindow2._setBackgroundColor = function(colorName) {
        var color = parseHexColor(colorName);
        webview.setValue_forKey(false, "drawsBackground");
        panel.backgroundColor = color;
      };
      browserWindow2._invalidate = function() {
        panel.flushWindow();
        panel.contentView().setNeedsDisplay(true);
      };
      browserWindow2._setStyleMask = function(on, flag) {
        var wasMaximizable = browserWindow2.isMaximizable();
        if (on) {
          panel.setStyleMask(panel.styleMask() | flag);
        } else {
          panel.setStyleMask(panel.styleMask() & ~flag);
        }
        browserWindow2.setMaximizable(wasMaximizable);
      };
      browserWindow2._setCollectionBehavior = function(on, flag) {
        var wasMaximizable = browserWindow2.isMaximizable();
        if (on) {
          panel.setCollectionBehavior(panel.collectionBehavior() | flag);
        } else {
          panel.setCollectionBehavior(panel.collectionBehavior() & ~flag);
        }
        browserWindow2.setMaximizable(wasMaximizable);
      };
      browserWindow2._showWindowButton = function(button) {
        var view = panel.standardWindowButton(button);
        view.superview().addSubview_positioned_relative(view, NSWindowAbove, null);
      };
    };
  }
});

// node_modules/sketch-module-web-view/lib/constants.js
var require_constants = __commonJS({
  "node_modules/sketch-module-web-view/lib/constants.js"(exports2, module2) {
    module2.exports = {
      JS_BRIDGE: "__skpm_sketchBridge",
      JS_BRIDGE_RESULT_SUCCESS: "__skpm_sketchBridge_success",
      JS_BRIDGE_RESULT_ERROR: "__skpm_sketchBridge_error",
      START_MOVING_WINDOW: "__skpm_startMovingWindow",
      EXECUTE_JAVASCRIPT: "__skpm_executeJS",
      EXECUTE_JAVASCRIPT_SUCCESS: "__skpm_executeJS_success_",
      EXECUTE_JAVASCRIPT_ERROR: "__skpm_executeJS_error_"
    };
  }
});

// node_modules/sketch-module-web-view/lib/execute-javascript.js
var require_execute_javascript = __commonJS({
  "node_modules/sketch-module-web-view/lib/execute-javascript.js"(exports2, module2) {
    var CONSTANTS = require_constants();
    module2.exports = function(webview, browserWindow2) {
      function executeJavaScript(script, userGesture, callback) {
        if (typeof userGesture === "function") {
          callback = userGesture;
          userGesture = false;
        }
        var fiber = coscript.createFiber();
        if (webview.navigationDelegate().state && webview.navigationDelegate().state.wasReady == 0) {
          return new Promise(function(resolve, reject) {
            browserWindow2.once("ready-to-show", function() {
              executeJavaScript(script, userGesture, callback).then(resolve).catch(reject);
              fiber.cleanup();
            });
          });
        }
        return new Promise(function(resolve, reject) {
          var requestId = Math.random();
          browserWindow2.webContents.on(
            CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS + requestId,
            function(res) {
              try {
                if (callback) {
                  callback(null, res);
                }
                resolve(res);
              } catch (err) {
                reject(err);
              }
              fiber.cleanup();
            }
          );
          browserWindow2.webContents.on(
            CONSTANTS.EXECUTE_JAVASCRIPT_ERROR + requestId,
            function(err) {
              try {
                if (callback) {
                  callback(err);
                  resolve();
                } else {
                  reject(err);
                }
              } catch (err2) {
                reject(err2);
              }
              fiber.cleanup();
            }
          );
          webview.evaluateJavaScript_completionHandler(
            module2.exports.wrapScript(script, requestId),
            null
          );
        });
      }
      return executeJavaScript;
    };
    module2.exports.wrapScript = function(script, requestId) {
      return "window." + CONSTANTS.EXECUTE_JAVASCRIPT + "(" + requestId + ", " + JSON.stringify(script) + ")";
    };
    module2.exports.injectScript = function(webView) {
      var source = "window." + CONSTANTS.EXECUTE_JAVASCRIPT + ' = function(id, script) {  try {    var res = eval(script);    if (res && typeof res.then === "function" && typeof res.catch === "function") {      res.then(function (res2) {        window.postMessage("' + CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS + '" + id, res2);      })      .catch(function (err) {        window.postMessage("' + CONSTANTS.EXECUTE_JAVASCRIPT_ERROR + '" + id, err);      })    } else {      window.postMessage("' + CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS + '" + id, res);    }  } catch (err) {    window.postMessage("' + CONSTANTS.EXECUTE_JAVASCRIPT_ERROR + '" + id, err);  }}';
      var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
        source,
        0,
        true
      );
      webView.configuration().userContentController().addUserScript(script);
    };
  }
});

// node_modules/sketch-module-web-view/lib/webview-api.js
var require_webview_api = __commonJS({
  "node_modules/sketch-module-web-view/lib/webview-api.js"(exports2, module2) {
    var EventEmitter = require_events();
    var executeJavaScript = require_execute_javascript();
    module2.exports = function buildAPI(browserWindow2, panel, webview) {
      var webContents = new EventEmitter();
      webContents.loadURL = browserWindow2.loadURL;
      webContents.loadFile = function() {
        console.warn(
          "Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)"
        );
      };
      webContents.downloadURL = function() {
        console.warn(
          "Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)"
        );
      };
      webContents.getURL = function() {
        return String(webview.URL());
      };
      webContents.getTitle = function() {
        return String(webview.title());
      };
      webContents.isDestroyed = function() {
        console.warn(
          "Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)"
        );
      };
      webContents.focus = browserWindow2.focus;
      webContents.isFocused = browserWindow2.isFocused;
      webContents.isLoading = function() {
        return !!webview.loading();
      };
      webContents.isLoadingMainFrame = function() {
        return !!webview.loading();
      };
      webContents.isWaitingForResponse = function() {
        return !webview.loading();
      };
      webContents.stop = function() {
        webview.stopLoading();
      };
      webContents.reload = function() {
        webview.reload();
      };
      webContents.reloadIgnoringCache = function() {
        webview.reloadFromOrigin();
      };
      webContents.canGoBack = function() {
        return !!webview.canGoBack();
      };
      webContents.canGoForward = function() {
        return !!webview.canGoForward();
      };
      webContents.canGoToOffset = function(offset) {
        return !!webview.backForwardList().itemAtIndex(offset);
      };
      webContents.clearHistory = function() {
        console.warn(
          "Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)"
        );
      };
      webContents.goBack = function() {
        webview.goBack();
      };
      webContents.goForward = function() {
        webview.goForward();
      };
      webContents.goToIndex = function(index) {
        var backForwardList = webview.backForwardList();
        var backList = backForwardList.backList();
        var backListLength = backList.count();
        if (backListLength > index) {
          webview.loadRequest(NSURLRequest.requestWithURL(backList[index]));
          return;
        }
        var forwardList = backForwardList.forwardList();
        if (forwardList.count() > index - backListLength) {
          webview.loadRequest(
            NSURLRequest.requestWithURL(forwardList[index - backListLength])
          );
          return;
        }
        throw new Error("Cannot go to index " + index);
      };
      webContents.goToOffset = function(offset) {
        if (!webContents.canGoToOffset(offset)) {
          throw new Error("Cannot go to offset " + offset);
        }
        webview.loadRequest(
          NSURLRequest.requestWithURL(webview.backForwardList().itemAtIndex(offset))
        );
      };
      webContents.isCrashed = function() {
        console.warn(
          "Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)"
        );
      };
      webContents.setUserAgent = function() {
        console.warn(
          "Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)"
        );
      };
      webContents.getUserAgent = function() {
        const userAgent = webview.customUserAgent();
        return userAgent ? String(userAgent) : void 0;
      };
      webContents.insertCSS = function(css) {
        var source = "var style = document.createElement('style'); style.innerHTML = " + css.replace(/"/, '\\"') + "; document.head.appendChild(style);";
        var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
          source,
          0,
          true
        );
        webview.configuration().userContentController().addUserScript(script);
      };
      webContents.insertJS = function(source) {
        var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
          source,
          0,
          true
        );
        webview.configuration().userContentController().addUserScript(script);
      };
      webContents.executeJavaScript = executeJavaScript(webview, browserWindow2);
      webContents.setIgnoreMenuShortcuts = function() {
        console.warn(
          "Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)"
        );
      };
      webContents.setAudioMuted = function() {
        console.warn(
          "Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)"
        );
      };
      webContents.isAudioMuted = function() {
        console.warn(
          "Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)"
        );
      };
      webContents.setZoomFactor = function(factor) {
        webview.setMagnification_centeredAtPoint(factor, CGPointMake(0, 0));
      };
      webContents.getZoomFactor = function(callback) {
        callback(Number(webview.magnification()));
      };
      webContents.setZoomLevel = function(level) {
        webContents.setZoomFactor(Math.pow(1.2, level));
      };
      webContents.getZoomLevel = function(callback) {
        callback(Math.log(Number(webview.magnification())) / Math.log(1.2));
      };
      webContents.setVisualZoomLevelLimits = function() {
        console.warn(
          "Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)"
        );
      };
      webContents.setLayoutZoomLevelLimits = function() {
        console.warn(
          "Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)"
        );
      };
      webContents.send = function() {
        const script = "window.postMessage({isSketchMessage: true,origin: '" + String(__command.identifier()) + "',args: " + JSON.stringify([].slice.call(arguments)) + '}, "*")';
        webview.evaluateJavaScript_completionHandler(script, null);
      };
      webContents.getNativeWebview = function() {
        return webview;
      };
      browserWindow2.webContents = webContents;
    };
  }
});

// node_modules/sketch-module-web-view/lib/fitSubview.js
var require_fitSubview = __commonJS({
  "node_modules/sketch-module-web-view/lib/fitSubview.js"(exports2, module2) {
    function addEdgeConstraint(edge, subview, view, constant) {
      view.addConstraint(
        NSLayoutConstraint.constraintWithItem_attribute_relatedBy_toItem_attribute_multiplier_constant(
          subview,
          edge,
          NSLayoutRelationEqual,
          view,
          edge,
          1,
          constant
        )
      );
    }
    module2.exports = function fitSubviewToView(subview, view, constants) {
      constants = constants || [];
      subview.setTranslatesAutoresizingMaskIntoConstraints(false);
      addEdgeConstraint(NSLayoutAttributeLeft, subview, view, constants[0] || 0);
      addEdgeConstraint(NSLayoutAttributeTop, subview, view, constants[1] || 0);
      addEdgeConstraint(NSLayoutAttributeRight, subview, view, constants[2] || 0);
      addEdgeConstraint(NSLayoutAttributeBottom, subview, view, constants[3] || 0);
    };
  }
});

// node_modules/sketch-module-web-view/lib/dispatch-first-click.js
var require_dispatch_first_click = __commonJS({
  "node_modules/sketch-module-web-view/lib/dispatch-first-click.js"(exports2, module2) {
    var tagsToFocus = '["text", "textarea", "date", "datetime-local", "email", "number", "month", "password", "search", "tel", "time", "url", "week" ]';
    module2.exports = function(webView, event) {
      var point = webView.convertPoint_fromView(event.locationInWindow(), null);
      return "var el = document.elementFromPoint(" + // get the DOM element that match the event
      point.x + ", " + point.y + '); if (el && el.tagName === "SELECT") {  var event = document.createEvent("MouseEvents");  event.initMouseEvent("mousedown", true, true, window);  el.dispatchEvent(event);} else if (el && ' + // some tags need to be focused instead of clicked
      tagsToFocus + '.indexOf(el.type) >= 0 && el.focus) {el.focus();} else if (el) {el.dispatchEvent(new Event("click", {bubbles: true}))}';
    };
  }
});

// node_modules/sketch-module-web-view/lib/inject-client-messaging.js
var require_inject_client_messaging = __commonJS({
  "node_modules/sketch-module-web-view/lib/inject-client-messaging.js"(exports2, module2) {
    var CONSTANTS = require_constants();
    module2.exports = function(webView) {
      var source = `window.originalPostMessage = window.postMessage;window.postMessage = function(actionName) {  if (!actionName) {    throw new Error('missing action name')  }  var id = String(Math.random()).replace(".", "");    var args = [].slice.call(arguments);    args.unshift(id);  return new Promise(function (resolve, reject) {    window["` + CONSTANTS.JS_BRIDGE_RESULT_SUCCESS + '" + id] = resolve;    window["' + CONSTANTS.JS_BRIDGE_RESULT_ERROR + '" + id] = reject;    window.webkit.messageHandlers.' + CONSTANTS.JS_BRIDGE + ".postMessage(JSON.stringify(args));  });}";
      var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
        source,
        0,
        true
      );
      webView.configuration().userContentController().addUserScript(script);
    };
  }
});

// node_modules/sketch-module-web-view/lib/movable-area.js
var require_movable_area = __commonJS({
  "node_modules/sketch-module-web-view/lib/movable-area.js"(exports2, module2) {
    var CONSTANTS = require_constants();
    module2.exports.injectScript = function(webView) {
      var source = `(function () {document.addEventListener('mousedown', onMouseDown);function shouldDrag(target) {  if (!target || (target.dataset || {}).appRegion === "no-drag") { return false }  if ((target.dataset || {}).appRegion === "drag") { return true }  return shouldDrag(target.parentElement)};function onMouseDown(e) {  if (e.button !== 0 || !shouldDrag(e.target)) { return }  window.postMessage("` + CONSTANTS.START_MOVING_WINDOW + '");};})()';
      var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
        source,
        0,
        true
      );
      webView.configuration().userContentController().addUserScript(script);
    };
    module2.exports.setupHandler = function(browserWindow2) {
      var initialMouseLocation = null;
      var initialWindowPosition = null;
      var interval = null;
      function moveWindow() {
        if (!initialWindowPosition || NSEvent.pressedMouseButtons() !== 1) {
          clearInterval(interval);
          initialMouseLocation = null;
          initialWindowPosition = null;
          return;
        }
        var mouse = NSEvent.mouseLocation();
        browserWindow2.setPosition(
          initialWindowPosition.x + (mouse.x - initialMouseLocation.x),
          initialWindowPosition.y + (initialMouseLocation.y - mouse.y),
          // y is inverted
          false
        );
      }
      browserWindow2.webContents.on(CONSTANTS.START_MOVING_WINDOW, function() {
        initialMouseLocation = NSEvent.mouseLocation();
        var position = browserWindow2.getPosition();
        initialWindowPosition = {
          x: position[0],
          y: position[1]
        };
        interval = setInterval(moveWindow, 1e3 / 60);
      });
    };
  }
});

// node_modules/mocha-js-delegate/index.js
var require_mocha_js_delegate = __commonJS({
  "node_modules/mocha-js-delegate/index.js"(exports, module) {
    module.exports = function MochaDelegate(definition, superclass) {
      var uniqueClassName = "MochaJSDelegate_DynamicClass_" + NSUUID.UUID().UUIDString();
      var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(
        uniqueClassName,
        superclass || NSObject
      );
      var handlers = {};
      var ivars = {};
      function setHandlerForSelector(selectorString, func) {
        var handlerHasBeenSet = selectorString in handlers;
        var selector = NSSelectorFromString(selectorString);
        handlers[selectorString] = func;
        if (!handlerHasBeenSet) {
          var args = [];
          var regex = /:/g;
          while (regex.exec(selectorString)) {
            args.push("arg" + args.length);
          }
          var dynamicFunction = eval(
            "(function (" + args.join(", ") + ") { return handlers[selectorString].apply(this, arguments); })"
          );
          delegateClassDesc.addInstanceMethodWithSelector_function(
            selector,
            dynamicFunction
          );
        }
      }
      function setIvar(key, value) {
        var ivarHasBeenSet = key in handlers;
        ivars[key] = value;
        if (!ivarHasBeenSet) {
          delegateClassDesc.addInstanceVariableWithName_typeEncoding(key, "@");
          var description = MOPropertyDescription.new();
          description.name = key;
          description.typeEncoding = "@";
          description.weak = true;
          description.ivarName = key;
          delegateClassDesc.addProperty(description);
        }
      }
      this.getClass = function() {
        return NSClassFromString(uniqueClassName);
      };
      this.getClassInstance = function(instanceVariables) {
        var instance = NSClassFromString(uniqueClassName).new();
        Object.keys(ivars).forEach(function(key) {
          instance[key] = ivars[key];
        });
        Object.keys(instanceVariables || {}).forEach(function(key) {
          instance[key] = instanceVariables[key];
        });
        return instance;
      };
      this.new = this.getClassInstance;
      if (typeof definition === "object") {
        Object.keys(definition).forEach(
          function(key) {
            if (typeof definition[key] === "function") {
              setHandlerForSelector(key, definition[key]);
            } else {
              setIvar(key, definition[key]);
            }
          }
        );
      }
      delegateClassDesc.registerClass();
    };
  }
});

// node_modules/sketch-module-web-view/lib/parseWebArguments.js
var require_parseWebArguments = __commonJS({
  "node_modules/sketch-module-web-view/lib/parseWebArguments.js"(exports2, module2) {
    module2.exports = function(webArguments) {
      var args2 = null;
      try {
        args2 = JSON.parse(webArguments);
      } catch (e) {
      }
      if (!args2 || !args2.constructor || args2.constructor !== Array || args2.length == 0) {
        return null;
      }
      return args2;
    };
  }
});

// node_modules/sketch-module-web-view/lib/set-delegates.js
var require_set_delegates = __commonJS({
  "node_modules/sketch-module-web-view/lib/set-delegates.js"(exports2, module2) {
    var ObjCClass = require_mocha_js_delegate();
    var parseWebArguments = require_parseWebArguments();
    var CONSTANTS = require_constants();
    var WindowDelegateClass;
    var NavigationDelegateClass;
    var WebScriptHandlerClass;
    var ThemeObserverClass;
    module2.exports = function(browserWindow2, panel, webview, options) {
      if (!ThemeObserverClass) {
        ThemeObserverClass = new ObjCClass({
          utils: null,
          "observeValueForKeyPath:ofObject:change:context:": function(keyPath, object, change) {
            const newAppearance = change[NSKeyValueChangeNewKey];
            const isDark = String(
              newAppearance.bestMatchFromAppearancesWithNames([
                "NSAppearanceNameAqua",
                "NSAppearanceNameDarkAqua"
              ])
            ) === "NSAppearanceNameDarkAqua";
            this.utils.executeJavaScript(
              "document.body.classList.remove('__skpm-" + (isDark ? "light" : "dark") + "'); document.body.classList.add('__skpm-" + (isDark ? "dark" : "light") + "')"
            );
          }
        });
      }
      if (!WindowDelegateClass) {
        WindowDelegateClass = new ObjCClass({
          utils: null,
          panel: null,
          "windowDidResize:": function() {
            this.utils.emit("resize");
          },
          "windowDidMiniaturize:": function() {
            this.utils.emit("minimize");
          },
          "windowDidDeminiaturize:": function() {
            this.utils.emit("restore");
          },
          "windowDidEnterFullScreen:": function() {
            this.utils.emit("enter-full-screen");
          },
          "windowDidExitFullScreen:": function() {
            this.utils.emit("leave-full-screen");
          },
          "windowDidMove:": function() {
            this.utils.emit("move");
            this.utils.emit("moved");
          },
          "windowShouldClose:": function() {
            var shouldClose = 1;
            this.utils.emit("close", {
              get defaultPrevented() {
                return !shouldClose;
              },
              preventDefault: function() {
                shouldClose = 0;
              }
            });
            return shouldClose;
          },
          "windowWillClose:": function() {
            this.utils.emit("closed");
          },
          "windowDidBecomeKey:": function() {
            this.utils.emit("focus", this.panel.currentEvent());
          },
          "windowDidResignKey:": function() {
            this.utils.emit("blur");
          }
        });
      }
      if (!NavigationDelegateClass) {
        NavigationDelegateClass = new ObjCClass({
          state: {
            wasReady: 0
          },
          utils: null,
          // // Called when the web view begins to receive web content.
          "webView:didCommitNavigation:": function(webView) {
            this.utils.emit("will-navigate", {}, String(String(webView.URL())));
          },
          // // Called when web content begins to load in a web view.
          "webView:didStartProvisionalNavigation:": function() {
            this.utils.emit("did-start-navigation");
            this.utils.emit("did-start-loading");
          },
          // Called when a web view receives a server redirect.
          "webView:didReceiveServerRedirectForProvisionalNavigation:": function() {
            this.utils.emit("did-get-redirect-request");
          },
          // // Called when the web view needs to respond to an authentication challenge.
          // 'webView:didReceiveAuthenticationChallenge:completionHandler:': function(
          //   webView,
          //   challenge,
          //   completionHandler
          // ) {
          //   function callback(username, password) {
          //     completionHandler(
          //       0,
          //       NSURLCredential.credentialWithUser_password_persistence(
          //         username,
          //         password,
          //         1
          //       )
          //     )
          //   }
          //   var protectionSpace = challenge.protectionSpace()
          //   this.utils.emit(
          //     'login',
          //     {},
          //     {
          //       method: String(protectionSpace.authenticationMethod()),
          //       url: 'not implemented', // TODO:
          //       referrer: 'not implemented', // TODO:
          //     },
          //     {
          //       isProxy: !!protectionSpace.isProxy(),
          //       scheme: String(protectionSpace.protocol()),
          //       host: String(protectionSpace.host()),
          //       port: Number(protectionSpace.port()),
          //       realm: String(protectionSpace.realm()),
          //     },
          //     callback
          //   )
          // },
          // Called when an error occurs during navigation.
          // 'webView:didFailNavigation:withError:': function(
          //   webView,
          //   navigation,
          //   error
          // ) {},
          // Called when an error occurs while the web view is loading content.
          "webView:didFailProvisionalNavigation:withError:": function(webView, navigation, error) {
            this.utils.emit("did-fail-load", error);
          },
          // Called when the navigation is complete.
          "webView:didFinishNavigation:": function() {
            if (this.state.wasReady == 0) {
              this.state.wasReady = 1;
              this.utils.emitBrowserEvent("ready-to-show");
            }
            this.utils.emit("did-navigate");
            this.utils.emit("did-frame-navigate");
            this.utils.emit("did-stop-loading");
            this.utils.emit("did-finish-load");
            this.utils.emit("did-frame-finish-load");
          },
          // Called when the web view’s web content process is terminated.
          "webViewWebContentProcessDidTerminate:": function() {
            this.utils.emit("dom-ready");
          }
          // Decides whether to allow or cancel a navigation.
          // webView:decidePolicyForNavigationAction:decisionHandler:
          // Decides whether to allow or cancel a navigation after its response is known.
          // webView:decidePolicyForNavigationResponse:decisionHandler:
        });
      }
      if (!WebScriptHandlerClass) {
        WebScriptHandlerClass = new ObjCClass({
          utils: null,
          "userContentController:didReceiveScriptMessage:": function(_, message) {
            var args2 = this.utils.parseWebArguments(String(message.body()));
            if (!args2) {
              return;
            }
            if (!args2[0] || typeof args2[0] !== "string") {
              return;
            }
            args2[0] = String(args2[0]);
            this.utils.emit.apply(this, args2);
          }
        });
      }
      var themeObserver = ThemeObserverClass.new({
        utils: {
          executeJavaScript(script2) {
            webview.evaluateJavaScript_completionHandler(script2, null);
          }
        }
      });
      var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
        "document.addEventListener('DOMContentLoaded', function() { document.body.classList.add('__skpm-" + (typeof MSTheme !== "undefined" && MSTheme.sharedTheme().isDark() ? "dark" : "light") + "') }, false)",
        0,
        true
      );
      webview.configuration().userContentController().addUserScript(script);
      NSApplication.sharedApplication().addObserver_forKeyPath_options_context(
        themeObserver,
        "effectiveAppearance",
        NSKeyValueObservingOptionNew,
        null
      );
      var threadDictionary = NSThread.mainThread().threadDictionary();
      threadDictionary[browserWindow2.id + ".themeObserver"] = themeObserver;
      var navigationDelegate = NavigationDelegateClass.new({
        utils: {
          setTitle: browserWindow2.setTitle.bind(browserWindow2),
          emitBrowserEvent() {
            try {
              browserWindow2.emit.apply(browserWindow2, arguments);
            } catch (err) {
              if (typeof process !== "undefined" && process.listenerCount && process.listenerCount("uncaughtException")) {
                process.emit("uncaughtException", err, "uncaughtException");
              } else {
                console.error(err);
                throw err;
              }
            }
          },
          emit() {
            try {
              browserWindow2.webContents.emit.apply(
                browserWindow2.webContents,
                arguments
              );
            } catch (err) {
              if (typeof process !== "undefined" && process.listenerCount && process.listenerCount("uncaughtException")) {
                process.emit("uncaughtException", err, "uncaughtException");
              } else {
                console.error(err);
                throw err;
              }
            }
          }
        },
        state: {
          wasReady: 0
        }
      });
      webview.setNavigationDelegate(navigationDelegate);
      var webScriptHandler = WebScriptHandlerClass.new({
        utils: {
          emit(id, type) {
            if (!type) {
              webview.evaluateJavaScript_completionHandler(
                CONSTANTS.JS_BRIDGE_RESULT_SUCCESS + id + "()",
                null
              );
              return;
            }
            var args2 = [];
            for (var i = 2; i < arguments.length; i += 1) args2.push(arguments[i]);
            var listeners = browserWindow2.webContents.listeners(type);
            Promise.all(
              listeners.map(function(l) {
                return Promise.resolve().then(function() {
                  return l.apply(l, args2);
                });
              })
            ).then(function(res) {
              webview.evaluateJavaScript_completionHandler(
                CONSTANTS.JS_BRIDGE_RESULT_SUCCESS + id + "(" + JSON.stringify(res) + ")",
                null
              );
            }).catch(function(err) {
              webview.evaluateJavaScript_completionHandler(
                CONSTANTS.JS_BRIDGE_RESULT_ERROR + id + "(" + JSON.stringify(err) + ")",
                null
              );
            });
          },
          parseWebArguments
        }
      });
      webview.configuration().userContentController().addScriptMessageHandler_name(webScriptHandler, CONSTANTS.JS_BRIDGE);
      var utils = {
        emit() {
          try {
            browserWindow2.emit.apply(browserWindow2, arguments);
          } catch (err) {
            if (typeof process !== "undefined" && process.listenerCount && process.listenerCount("uncaughtException")) {
              process.emit("uncaughtException", err, "uncaughtException");
            } else {
              console.error(err);
              throw err;
            }
          }
        }
      };
      if (options.modal) {
        var msdocument;
        if (options.parent.type === "Document") {
          msdocument = options.parent.sketchObject;
        } else {
          msdocument = options.parent;
        }
        if (msdocument && String(msdocument.class()) === "MSDocumentData") {
          msdocument = msdocument.delegate();
        }
        utils.parentWindow = msdocument.windowForSheet();
      }
      var windowDelegate = WindowDelegateClass.new({
        utils,
        panel
      });
      panel.setDelegate(windowDelegate);
    };
  }
});

// node_modules/sketch-module-web-view/lib/index.js
var require_lib = __commonJS({
  "node_modules/sketch-module-web-view/lib/index.js"(exports2, module2) {
    var EventEmitter = require_events();
    var buildBrowserAPI = require_browser_api();
    var buildWebAPI = require_webview_api();
    var fitSubviewToView = require_fitSubview();
    var dispatchFirstClick = require_dispatch_first_click();
    var injectClientMessaging = require_inject_client_messaging();
    var movableArea = require_movable_area();
    var executeJavaScript = require_execute_javascript();
    var setDelegates = require_set_delegates();
    function BrowserWindow(options) {
      options = options || {};
      var identifier = options.identifier || String(NSUUID.UUID().UUIDString());
      var threadDictionary = NSThread.mainThread().threadDictionary();
      var existingBrowserWindow = BrowserWindow.fromId(identifier);
      if (existingBrowserWindow) {
        return existingBrowserWindow;
      }
      var browserWindow2 = new EventEmitter();
      browserWindow2.id = identifier;
      if (options.modal && !options.parent) {
        throw new Error("A modal needs to have a parent.");
      }
      var fiber = coscript.createFiber();
      var width = options.width || 800;
      var height = options.height || 600;
      var mainScreenRect = NSScreen.screens().firstObject().frame();
      var cocoaBounds = NSMakeRect(
        typeof options.x !== "undefined" ? options.x : Math.round((NSWidth(mainScreenRect) - width) / 2),
        typeof options.y !== "undefined" ? NSHeight(mainScreenRect) - options.y : Math.round((NSHeight(mainScreenRect) - height) / 2),
        width,
        height
      );
      if (options.titleBarStyle && options.titleBarStyle !== "default") {
        options.frame = false;
      }
      var useStandardWindow = options.windowType !== "textured";
      var styleMask = NSTitledWindowMask;
      if (options.minimizable !== false) {
        styleMask |= NSMiniaturizableWindowMask;
      }
      if (options.closable !== false) {
        styleMask |= NSClosableWindowMask;
      }
      if (options.resizable !== false) {
        styleMask |= NSResizableWindowMask;
      }
      if (!useStandardWindow || options.transparent || options.frame === false) {
        styleMask |= NSTexturedBackgroundWindowMask;
      }
      var panel = NSPanel.alloc().initWithContentRect_styleMask_backing_defer(
        cocoaBounds,
        styleMask,
        NSBackingStoreBuffered,
        true
      );
      var wkwebviewConfig = WKWebViewConfiguration.alloc().init();
      var webView = WKWebView.alloc().initWithFrame_configuration(
        CGRectMake(0, 0, options.width || 800, options.height || 600),
        wkwebviewConfig
      );
      injectClientMessaging(webView);
      webView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable);
      buildBrowserAPI(browserWindow2, panel, webView);
      buildWebAPI(browserWindow2, panel, webView);
      setDelegates(browserWindow2, panel, webView, options);
      if (options.windowType === "desktop") {
        panel.setLevel(kCGDesktopWindowLevel - 1);
        panel.setCollectionBehavior(
          NSWindowCollectionBehaviorCanJoinAllSpaces | NSWindowCollectionBehaviorStationary | NSWindowCollectionBehaviorIgnoresCycle
        );
      }
      if (typeof options.minWidth !== "undefined" || typeof options.minHeight !== "undefined") {
        browserWindow2.setMinimumSize(options.minWidth || 0, options.minHeight || 0);
      }
      if (typeof options.maxWidth !== "undefined" || typeof options.maxHeight !== "undefined") {
        browserWindow2.setMaximumSize(
          options.maxWidth || 1e4,
          options.maxHeight || 1e4
        );
      }
      if (options.transparent || options.frame === false) {
        panel.titlebarAppearsTransparent = true;
        panel.titleVisibility = NSWindowTitleHidden;
        panel.setOpaque(0);
        panel.isMovableByWindowBackground = true;
        var toolbar2 = NSToolbar.alloc().initWithIdentifier(
          "titlebarStylingToolbar"
        );
        toolbar2.setShowsBaselineSeparator(false);
        panel.setToolbar(toolbar2);
      }
      if (options.titleBarStyle === "hiddenInset") {
        var toolbar = NSToolbar.alloc().initWithIdentifier("titlebarStylingToolbar");
        toolbar.setShowsBaselineSeparator(false);
        panel.setToolbar(toolbar);
      }
      if (options.frame === false || !options.useContentSize) {
        browserWindow2.setSize(width, height);
      }
      if (options.center) {
        browserWindow2.center();
      }
      if (options.alwaysOnTop) {
        browserWindow2.setAlwaysOnTop(true);
      }
      if (options.fullscreen) {
        browserWindow2.setFullScreen(true);
      }
      browserWindow2.setFullScreenable(!!options.fullscreenable);
      let title = options.title;
      if (options.frame === false) {
        title = void 0;
      } else if (typeof title === "undefined" && typeof __command !== "undefined" && __command.pluginBundle()) {
        title = __command.pluginBundle().name();
      }
      if (title) {
        browserWindow2.setTitle(title);
      }
      var backgroundColor = options.backgroundColor;
      if (options.transparent) {
        backgroundColor = NSColor.clearColor();
      }
      if (!backgroundColor && options.frame === false && options.vibrancy) {
        backgroundColor = NSColor.clearColor();
      }
      browserWindow2._setBackgroundColor(
        backgroundColor || NSColor.windowBackgroundColor()
      );
      if (options.hasShadow === false) {
        browserWindow2.setHasShadow(false);
      }
      if (typeof options.opacity !== "undefined") {
        browserWindow2.setOpacity(options.opacity);
      }
      options.webPreferences = options.webPreferences || {};
      webView.configuration().preferences().setValue_forKey(
        options.webPreferences.devTools !== false,
        "developerExtrasEnabled"
      );
      webView.configuration().preferences().setValue_forKey(
        options.webPreferences.javascript !== false,
        "javaScriptEnabled"
      );
      webView.configuration().preferences().setValue_forKey(!!options.webPreferences.plugins, "plugInsEnabled");
      webView.configuration().preferences().setValue_forKey(
        options.webPreferences.minimumFontSize || 0,
        "minimumFontSize"
      );
      if (options.webPreferences.zoomFactor) {
        webView.setMagnification(options.webPreferences.zoomFactor);
      }
      var contentView = panel.contentView();
      if (options.frame !== false) {
        webView.setFrame(contentView.bounds());
        contentView.addSubview(webView);
      } else {
        contentView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable);
        fitSubviewToView(contentView, contentView.superview());
        webView.setFrame(contentView.bounds());
        contentView.addSubview(webView);
        if (panel.standardWindowButton(NSWindowFullScreenButton)) {
          panel.standardWindowButton(NSWindowFullScreenButton).setHidden(true);
        }
        if (!options.titleBarStyle || options.titleBarStyle === "default") {
          panel.standardWindowButton(NSWindowZoomButton).setHidden(true);
          panel.standardWindowButton(NSWindowMiniaturizeButton).setHidden(true);
          panel.standardWindowButton(NSWindowCloseButton).setHidden(true);
          panel.standardWindowButton(NSWindowZoomButton).setEnabled(false);
        }
      }
      if (options.vibrancy) {
        browserWindow2.setVibrancy(options.vibrancy);
      }
      browserWindow2.setMaximizable(options.maximizable !== false);
      panel.setHidesOnDeactivate(options.hidesOnDeactivate !== false);
      if (options.remembersWindowFrame) {
        panel.setFrameAutosaveName(identifier);
        panel.setFrameUsingName_force(panel.frameAutosaveName(), false);
      }
      if (options.acceptsFirstMouse) {
        browserWindow2.on("focus", function(event) {
          if (event.type() === NSEventTypeLeftMouseDown) {
            browserWindow2.webContents.executeJavaScript(dispatchFirstClick(webView, event)).catch(() => {
            });
          }
        });
      }
      executeJavaScript.injectScript(webView);
      movableArea.injectScript(webView);
      movableArea.setupHandler(browserWindow2);
      if (options.show !== false) {
        browserWindow2.show();
      }
      browserWindow2.on("closed", function() {
        browserWindow2._destroyed = true;
        threadDictionary.removeObjectForKey(identifier);
        var observer = threadDictionary[identifier + ".themeObserver"];
        if (observer) {
          NSApplication.sharedApplication().removeObserver_forKeyPath(
            observer,
            "effectiveAppearance"
          );
          threadDictionary.removeObjectForKey(identifier + ".themeObserver");
        }
        fiber.cleanup();
      });
      threadDictionary[identifier] = panel;
      fiber.onCleanup(function() {
        if (!browserWindow2._destroyed) {
          browserWindow2.destroy();
        }
      });
      return browserWindow2;
    }
    BrowserWindow.fromId = function(identifier) {
      var threadDictionary = NSThread.mainThread().threadDictionary();
      if (threadDictionary[identifier]) {
        return BrowserWindow.fromPanel(threadDictionary[identifier], identifier);
      }
      return void 0;
    };
    BrowserWindow.fromPanel = function(panel, identifier) {
      var browserWindow2 = new EventEmitter();
      browserWindow2.id = identifier;
      if (!panel || !panel.contentView) {
        throw new Error("needs to pass an NSPanel");
      }
      var webView = null;
      var subviews = panel.contentView().subviews();
      for (var i = 0; i < subviews.length; i += 1) {
        if (!webView && !subviews[i].isKindOfClass(WKInspectorWKWebView) && subviews[i].isKindOfClass(WKWebView)) {
          webView = subviews[i];
        }
      }
      if (!webView) {
        throw new Error("The panel needs to have a webview");
      }
      buildBrowserAPI(browserWindow2, panel, webView);
      buildWebAPI(browserWindow2, panel, webView);
      setDelegates(browserWindow2, panel, webView, {});
      return browserWindow2;
    };
    module2.exports = BrowserWindow;
  }
});

// src/artwork-url.ts
function artworkUrl(value) {
  if (typeof value !== "string" || value.length === 0 || value.length > 2e3) return void 0;
  try {
    const url = new URL(value);
    const host = url.hostname;
    const allowed = host === "mzstatic.com" || host.endsWith(".mzstatic.com");
    if (url.protocol !== "https:" || !allowed) return void 0;
    return url.toString();
  } catch {
    return void 0;
  }
}

// src/countries.ts
var STORE_COUNTRIES = [
  { code: "US", name: "United States" },
  { code: "CN", name: "China" },
  { code: "HK", name: "Hong Kong" },
  { code: "TW", name: "Taiwan" },
  { code: "JP", name: "Japan" },
  { code: "KR", name: "Korea" },
  { code: "GB", name: "United Kingdom" },
  { code: "DE", name: "Germany" },
  { code: "FR", name: "France" },
  { code: "CA", name: "Canada" },
  { code: "AU", name: "Australia" },
  { code: "SG", name: "Singapore" },
  { code: "IN", name: "India" },
  { code: "BR", name: "Brazil" },
  { code: "ES", name: "Spain" },
  { code: "IT", name: "Italy" },
  { code: "MX", name: "Mexico" },
  { code: "NL", name: "Netherlands" },
  { code: "SE", name: "Sweden" },
  { code: "TR", name: "Turkey" }
];
var DEFAULT_STORE_COUNTRY = "US";
var ALLOWED_COUNTRIES = new Set(STORE_COUNTRIES.map((country) => country.code));
function normalizeCountry(value) {
  const code = value?.trim().toUpperCase() ?? "";
  return ALLOWED_COUNTRIES.has(code) ? code : DEFAULT_STORE_COUNTRY;
}

// src/itunes.ts
var SEARCH_LIMIT = "30";
var MAX_TERM_LENGTH = 200;
function itunesSearchUrl(term, country) {
  const params = [
    "media=software",
    `limit=${SEARCH_LIMIT}`,
    `term=${encodeURIComponent(term.trim().slice(0, MAX_TERM_LENGTH))}`,
    `country=${encodeURIComponent(normalizeCountry(country))}`
  ];
  return `https://itunes.apple.com/search?${params.join("&")}`;
}
function appsFromItunes(payload) {
  if (!payload || typeof payload !== "object") return [];
  const results = payload.results;
  if (!Array.isArray(results)) return [];
  const apps = [];
  for (const item of results) {
    const app = normalizeRow(item);
    if (app) apps.push(app);
  }
  return apps;
}
function normalizeRow(item) {
  if (!item || typeof item !== "object") return void 0;
  const row = item;
  if (row.kind !== "software" && row.kind !== "mac-software") return void 0;
  if (typeof row.trackId !== "number" || typeof row.trackName !== "string") return void 0;
  const artwork = artworkUrl(row.artworkUrl512) ?? artworkUrl(row.artworkUrl100);
  if (!artwork) return void 0;
  return {
    trackId: row.trackId,
    trackName: row.trackName,
    artistName: typeof row.artistName === "string" ? row.artistName : "",
    artworkUrl: artwork,
    primaryGenreName: typeof row.primaryGenreName === "string" ? row.primaryGenreName : void 0
  };
}

// src/recent.ts
var RECENT_LIMIT = 6;
var MAX_TERM_LENGTH2 = 80;
function normalizeRecent(value) {
  const items = asList(value);
  const seen = /* @__PURE__ */ new Set();
  const next = [];
  for (const item of items) {
    const cleaned = cleanTerm(item);
    if (!cleaned) continue;
    const key = cleaned.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(cleaned);
    if (next.length >= RECENT_LIMIT) break;
  }
  return next;
}
function cleanTerm(value) {
  if (typeof value !== "string") return "";
  return value.trim().replace(/\s+/g, " ").slice(0, MAX_TERM_LENGTH2);
}
function asList(value) {
  if (Array.isArray(value)) return value;
  if (value && typeof value === "object" && typeof value.count === "function") {
    const list = value;
    const count = Number(list.count());
    const items = [];
    for (let index = 0; index < count; index += 1) items.push(String(list.objectAtIndex(index)));
    return items;
  }
  return [];
}

// src/plugin.ts
var COUNTRY_KEY = "app-icons.country";
var RECENT_KEY = "app-icons.recent";
var WINDOW_ID = "design.uwarp.app-icons.panel";
var ALLOWED_URLS = /* @__PURE__ */ new Set(["https://www.uwarp.design/privacy-policy", "https://www.uwarp.design/logo-hunter"]);
var MAX_PNG_CHARS = 8e6;
var UTF8 = 4;
var PNG_TYPE = 4;
var browserWindow = null;
var searchGeneration = 0;
var insertCount = 0;
function openPanel(context) {
  if (browserWindow) {
    browserWindow.show();
    return;
  }
  const BrowserWindow = require_lib();
  const html = resourceURL(context, "webview.html");
  if (!html) {
    require("sketch").UI.message("App Icons is missing its interface.");
    return;
  }
  browserWindow = new BrowserWindow({
    identifier: WINDOW_ID,
    title: "App Icons",
    width: 400,
    height: 680,
    minWidth: 320,
    minHeight: 520,
    useContentSize: true,
    remembersWindowFrame: true,
    hidesOnDeactivate: false,
    center: true,
    show: true,
    resizable: true,
    maximizable: false,
    minimizable: true,
    fullscreenable: false,
    backgroundColor: "#f4f4f5",
    webPreferences: { devTools: false }
  });
  browserWindow.on("closed", () => {
    browserWindow = null;
  });
  const contents = browserWindow.webContents;
  contents.on("did-finish-load", () => sendInit());
  contents.on("ready", () => sendInit());
  contents.on("cancel", () => {
    searchGeneration += 1;
  });
  contents.on("search", (payload) => search(readRecord(payload)));
  contents.on("setCountry", (payload) => saveCountry(readRecord(payload)));
  contents.on("setRecent", (payload) => saveRecent(readRecord(payload)));
  contents.on("open", (payload) => openExternal(readRecord(payload)));
  contents.on("insert", (payload) => insert(readRecord(payload)));
  browserWindow.loadURL(html);
}
function sendInit() {
  post({
    type: "init",
    country: readCountry(),
    recent: readRecent()
  });
}
function search(payload) {
  const requestId = payload?.requestId;
  const query = payload?.query;
  const country = payload?.country;
  if (typeof requestId !== "number" || typeof query !== "string" || typeof country !== "string") return;
  const generation = ++searchGeneration;
  try {
    const data = readData(itunesSearchUrl(query, country));
    const apps = appsFromItunes(JSON.parse(dataToString(data)));
    if (generation !== searchGeneration) return;
    post({ type: "results", requestId, apps, status: "success" });
  } catch {
    if (generation !== searchGeneration) return;
    post({ type: "results", requestId, apps: [], status: "error" });
  }
}
function insert(payload) {
  const artwork = artworkUrl(payload?.artworkUrl);
  const name = typeof payload?.name === "string" ? payload.name.slice(0, 200) : "";
  if (!artwork) {
    post({ type: "insertResult", status: "failed" });
    return;
  }
  try {
    const base64 = dataToPngBase64(readData(artwork));
    if (!base64.startsWith("iVBORw0KGgo") || base64.length > MAX_PNG_CHARS) {
      post({ type: "insertResult", status: "failed" });
      return;
    }
    const status = placeImage(base64, name);
    post({ type: "insertResult", status });
  } catch {
    post({ type: "insertResult", status: "failed" });
  }
}
function placeImage(base64, name) {
  const sketch = require("sketch");
  const { Image } = require("sketch/dom");
  const document = sketch.getSelectedDocument();
  if (!document) {
    sketch.UI.message("Open a Sketch document to insert an icon.");
    return "nodoc";
  }
  const target = insertionTarget(document);
  const layer = new Image({
    parent: target.parent,
    name: layerName(name),
    image: { base64 },
    frame: new sketch.Rectangle(target.x, target.y, 128, 128)
  });
  if (typeof document.selectedLayers?.clear === "function") document.selectedLayers.clear();
  layer.selected = true;
  sketch.UI.message(`Inserted ${layer.name}`);
  return "inserted";
}
function insertionTarget(document) {
  const layers = selectedLayers(document);
  const selected = layers.length === 1 ? layers[0] : void 0;
  const nudge = insertCount % 6 * 16;
  insertCount += 1;
  if (selected && canContain(selected)) {
    return { parent: selected, x: 32 + nudge, y: 32 + nudge };
  }
  const frame = selected?.frame;
  if (selected && frame && typeof frame.x === "number" && typeof frame.y === "number") {
    return { parent: document.selectedPage, x: frame.x + 24 + nudge, y: frame.y + 24 + nudge };
  }
  return { parent: document.selectedPage, x: 80 + nudge, y: 80 + nudge };
}
function selectedLayers(document) {
  const layers = document.selectedLayers?.layers;
  if (Array.isArray(layers)) return layers;
  if (!layers || typeof layers.length !== "number") return [];
  const list = [];
  for (let index = 0; index < layers.length; index += 1) {
    const layer = layers[index];
    if (layer) list.push(layer);
  }
  return list;
}
function canContain(layer) {
  return layer.type === "Group" || layer.type === "Artboard";
}
function layerName(name) {
  const base = name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, "").replace(/\s+/g, " ").trim().slice(0, 80);
  return base || "App Icon";
}
function saveCountry(payload) {
  if (typeof payload?.country !== "string") return;
  require("sketch/settings").setGlobalSettingForKey(COUNTRY_KEY, normalizeCountry(payload.country));
}
function saveRecent(payload) {
  require("sketch/settings").setGlobalSettingForKey(RECENT_KEY, normalizeRecent(payload?.recent));
}
function readCountry() {
  return normalizeCountry(settingString(require("sketch/settings").globalSettingForKey(COUNTRY_KEY)));
}
function readRecent() {
  return normalizeRecent(require("sketch/settings").globalSettingForKey(RECENT_KEY));
}
function openExternal(payload) {
  const url = payload?.url;
  if (typeof url !== "string" || !ALLOWED_URLS.has(url)) return;
  NSWorkspace.sharedWorkspace().openURL(NSURL.URLWithString(url));
}
function post(message) {
  if (!browserWindow) return;
  const json = JSON.stringify(message).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
  browserWindow.webContents.executeJavaScript(`window.appIcons && window.appIcons.onHost(${json})`);
}
function readData(urlString) {
  const request = NSURLRequest.requestWithURL_cachePolicy_timeoutInterval(NSURL.URLWithString(urlString), 0, 12);
  const responsePtr = MOPointer.alloc().init();
  const errorPtr = MOPointer.alloc().init();
  const data = NSURLConnection.sendSynchronousRequest_returningResponse_error(request, responsePtr, errorPtr);
  const error = errorPtr.value();
  if (!data || error) throw new Error(error ? String(error.localizedDescription()) : "The request failed.");
  const response = responsePtr.value();
  const status = response && typeof response.statusCode === "function" ? Number(response.statusCode()) : 200;
  if (status < 200 || status >= 300) throw new Error(`Request failed (${status})`);
  return data;
}
function dataToString(data) {
  return String(NSString.alloc().initWithData_encoding(data, UTF8));
}
function dataToPngBase64(data) {
  const image = NSImage.alloc().initWithData(data);
  const tiff = image && typeof image.TIFFRepresentation === "function" ? image.TIFFRepresentation() : null;
  const rep = tiff ? NSBitmapImageRep.imageRepWithData(tiff) : null;
  const png = rep ? rep.representationUsingType_properties(PNG_TYPE, null) : null;
  if (!png || typeof png.base64EncodedStringWithOptions !== "function") throw new Error("png encode failed");
  return String(png.base64EncodedStringWithOptions(0));
}
function resourceURL(context, name) {
  const url = context.plugin?.urlForResourceNamed?.(name);
  if (!url || typeof url.absoluteString !== "function") return "";
  return String(url.absoluteString());
}
function readRecord(value) {
  if (typeof value === "string") {
    try {
      return readRecord(JSON.parse(value));
    } catch {
      return void 0;
    }
  }
  if (typeof value === "object" && value !== null) return value;
  return void 0;
}
function settingString(value) {
  if (typeof value === "string") return value;
  if (value == null) return void 0;
  const text = String(value);
  return text.startsWith("<") ? void 0 : text;
}
globalThis.onRun = openPanel;
function onRun(context){ if (typeof globalThis.onRun === "function") globalThis.onRun(context); }
