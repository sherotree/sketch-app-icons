"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

  // src/artwork-url.ts
  function artworkUrl(value) {
    if (typeof value !== "string" || value.length === 0 || value.length > 2e3) return void 0;
    try {
      const url = new URL(value);
      const host2 = url.hostname;
      const allowed = host2 === "mzstatic.com" || host2.endsWith(".mzstatic.com");
      if (url.protocol !== "https:" || !allowed) return void 0;
      return url.toString();
    } catch {
      return void 0;
    }
  }

  // src/countries.ts
  var STORE_COUNTRIES = [
    { code: "US", name: "United States" },
    { code: "CN", name: "China" },
    { code: "HK", name: "Hong Kong" },
    { code: "TW", name: "Taiwan" },
    { code: "JP", name: "Japan" },
    { code: "KR", name: "Korea" },
    { code: "GB", name: "United Kingdom" },
    { code: "DE", name: "Germany" },
    { code: "FR", name: "France" },
    { code: "CA", name: "Canada" },
    { code: "AU", name: "Australia" },
    { code: "SG", name: "Singapore" },
    { code: "IN", name: "India" },
    { code: "BR", name: "Brazil" },
    { code: "ES", name: "Spain" },
    { code: "IT", name: "Italy" },
    { code: "MX", name: "Mexico" },
    { code: "NL", name: "Netherlands" },
    { code: "SE", name: "Sweden" },
    { code: "TR", name: "Turkey" }
  ];
  var DEFAULT_STORE_COUNTRY = "US";
  var ALLOWED_COUNTRIES = new Set(STORE_COUNTRIES.map((country) => country.code));
  function normalizeCountry(value) {
    const code = value?.trim().toUpperCase() ?? "";
    return ALLOWED_COUNTRIES.has(code) ? code : DEFAULT_STORE_COUNTRY;
  }

  // src/recent.ts
  var RECENT_LIMIT = 6;
  var MAX_TERM_LENGTH = 80;
  function normalizeRecent(value) {
    const items = asList(value);
    const seen = /* @__PURE__ */ new Set();
    const next = [];
    for (const item of items) {
      const cleaned = cleanTerm(item);
      if (!cleaned) continue;
      const key = cleaned.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      next.push(cleaned);
      if (next.length >= RECENT_LIMIT) break;
    }
    return next;
  }
  function rememberRecent(current, term) {
    const cleaned = cleanTerm(term);
    if (!cleaned) return normalizeRecent(current);
    return normalizeRecent([cleaned, ...current]);
  }
  function forgetRecent(current, term) {
    return current.filter((item) => item !== term);
  }
  function cleanTerm(value) {
    if (typeof value !== "string") return "";
    return value.trim().replace(/\s+/g, " ").slice(0, MAX_TERM_LENGTH);
  }
  function asList(value) {
    if (Array.isArray(value)) return value;
    if (value && typeof value === "object" && typeof value.count === "function") {
      const list = value;
      const count = Number(list.count());
      const items = [];
      for (let index = 0; index < count; index += 1) items.push(String(list.objectAtIndex(index)));
      return items;
    }
    return [];
  }

  // src/webview/copy.ts
  var copy = {
    searchLabel: "Search apps",
    searchPlaceholder: "Search apps, e.g. Notion",
    clearSearch: "Clear search",
    regionLabel: "App Store region",
    suggestionsLabel: "Try a search",
    suggestions: ["Notion", "Figma", "Spotify", "Linear", "Slack", "Things"],
    recent: "Recent",
    removeRecent: "Remove",
    loading: "Searching the App Store",
    resultCount: (count) => count === 1 ? "1 app" : `${count} apps`,
    noResults: "No apps found",
    noResultsHint: "Try another name, or switch the store region.",
    errorTitle: "Search unavailable",
    errorHint: "Check your connection and try again.",
    retry: "Try again",
    resultsLabel: "Search results",
    idleTitle: "Find an app icon",
    idleBody: "Search by name, pick a result, then insert a PNG.",
    insert: "Insert PNG",
    inserting: "Inserting\u2026",
    inserted: "Inserted",
    insertFailed: "Could not insert this icon. Try again.",
    noDocument: "Open a Sketch document to insert an icon.",
    rights: "Icons belong to their publishers. Get permission before you publish them.",
    privacy: "Privacy",
    privacyTitle: "What this plugin sends",
    privacyBody: "The name you search and the region you pick are sent to Apple\u2019s App Store search. Uwarp does not receive those searches. Icon files are downloaded from Apple only when you insert one.",
    privacyLocal: "Your region and recent searches stay in Sketch. Removing the plugin clears them.",
    privacyPolicy: "Privacy policy",
    webTool: "Open the web version",
    close: "Close",
    selectedLabel: "Selected app"
  };

  // src/webview/main.ts
  var DEBOUNCE_MS = 280;
  var WATCHDOG_MS = 2e4;
  var host = window;
  var AppView = class {
    constructor() {
      __publicField(this, "form", required(HTMLFormElement, "search-form"));
      __publicField(this, "input", required(HTMLInputElement, "query"));
      __publicField(this, "clearButton", required(HTMLButtonElement, "clear"));
      __publicField(this, "countrySelect", required(HTMLSelectElement, "country"));
      __publicField(this, "progress", required(HTMLElement, "progress"));
      __publicField(this, "statusNode", required(HTMLElement, "status"));
      __publicField(this, "stage", required(HTMLElement, "stage"));
      __publicField(this, "dock", required(HTMLElement, "dock"));
      __publicField(this, "dialog", required(HTMLDialogElement, "privacy-dialog"));
      __publicField(this, "query", "");
      __publicField(this, "submitted", "");
      __publicField(this, "country", "US");
      __publicField(this, "recent", []);
      __publicField(this, "apps", []);
      __publicField(this, "status", "idle");
      __publicField(this, "selectedId");
      __publicField(this, "requestId", 0);
      __publicField(this, "composing", false);
      __publicField(this, "countryTouched", false);
      __publicField(this, "recentTouched", false);
      __publicField(this, "savedToken", "");
      __publicField(this, "busy", false);
      __publicField(this, "notice", null);
      __publicField(this, "insertTrackId");
      __publicField(this, "stageKey", "");
      __publicField(this, "resultsNode");
      __publicField(this, "dockTrackId");
      __publicField(this, "dockButton");
      __publicField(this, "dockLabel");
      __publicField(this, "dockNotice");
      __publicField(this, "timer");
      __publicField(this, "watchdog");
      host.onHost = (message) => this.onHost(message);
      this.applyCopy();
      this.fillCountries();
      this.bind();
      this.render();
      send("ready");
    }
    onHost(message) {
      const record = readRecord(message);
      if (!record) return;
      if (record.type === "init" && typeof record.country === "string") {
        this.applyInit(record.country, normalizeRecent(record.recent));
        return;
      }
      if (record.type === "results" && typeof record.requestId === "number") {
        const status = record.status === "error" ? "error" : "success";
        this.applyResults(record.requestId, readApps(record.apps), status);
        return;
      }
      if (record.type === "insertResult") this.applyInsert(readInsertStatus(record.status));
    }
    applyCopy() {
      text("search-label", copy.searchLabel);
      text("region-label", copy.regionLabel);
      text("privacy", copy.privacy);
      text("privacy-title", copy.privacyTitle);
      text("privacy-body", copy.privacyBody);
      text("privacy-local", copy.privacyLocal);
      text("rights", copy.rights);
      text("privacy-policy", copy.privacyPolicy);
      text("web-tool", copy.webTool);
      text("privacy-close", copy.close);
      this.input.placeholder = copy.searchPlaceholder;
      this.input.setAttribute("aria-label", copy.searchLabel);
      this.clearButton.setAttribute("aria-label", copy.clearSearch);
      this.countrySelect.setAttribute("aria-label", copy.regionLabel);
      this.dialog.setAttribute("aria-labelledby", "privacy-title");
    }
    fillCountries() {
      for (const country of STORE_COUNTRIES) {
        const option = document.createElement("option");
        option.value = country.code;
        option.textContent = country.name;
        this.countrySelect.append(option);
      }
      this.countrySelect.value = this.country;
    }
    bind() {
      this.form.addEventListener("submit", (event) => {
        event.preventDefault();
        this.stage.querySelector('[data-result="true"]')?.focus();
      });
      this.input.addEventListener("input", () => {
        this.query = this.input.value;
        this.syncClear();
        if (this.composing) {
          window.clearTimeout(this.timer);
          this.render();
          return;
        }
        this.scheduleSearch();
      });
      this.input.addEventListener("compositionstart", () => {
        this.composing = true;
        window.clearTimeout(this.timer);
      });
      this.input.addEventListener("compositionend", () => {
        this.composing = false;
        this.query = this.input.value;
        this.scheduleSearch();
      });
      this.input.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && this.query) {
          event.preventDefault();
          this.setQuery("", true);
        }
      });
      this.clearButton.addEventListener("click", () => {
        this.setQuery("", true);
        this.input.focus();
      });
      this.countrySelect.addEventListener("change", () => {
        this.country = normalizeCountry(this.countrySelect.value);
        this.countryTouched = true;
        send("setCountry", { country: this.country });
        if (this.query.trim()) this.flushSearch();
      });
      required(HTMLButtonElement, "privacy").addEventListener("click", () => this.dialog.showModal());
      required(HTMLButtonElement, "privacy-close").addEventListener("click", () => this.dialog.close());
      this.dialog.addEventListener("click", (event) => {
        if (event.target === this.dialog) this.dialog.close();
      });
      for (const id of ["privacy-policy", "web-tool"]) {
        required(HTMLButtonElement, id).addEventListener("click", (event) => {
          const url = event.currentTarget instanceof HTMLButtonElement ? event.currentTarget.dataset.url : void 0;
          if (url) send("open", { url });
        });
      }
    }
    applyInit(country, recent) {
      if (!this.countryTouched) {
        const next = normalizeCountry(country);
        const changed = next !== this.country;
        this.country = next;
        this.countrySelect.value = next;
        if (changed && this.submitted) this.flushSearch();
      }
      if (!this.recentTouched) this.recent = recent;
      this.render();
    }
    applyResults(requestId, apps, status) {
      if (requestId !== this.requestId) return;
      window.clearTimeout(this.watchdog);
      if (status === "error") {
        this.apps = [];
        this.status = "error";
        this.selectedId = void 0;
      } else {
        this.apps = apps;
        this.status = "success";
        this.ensureSelection();
        this.maybeRemember();
      }
      this.render();
    }
    applyInsert(status) {
      const sameApp = this.insertTrackId === this.selectedId;
      this.busy = false;
      this.insertTrackId = void 0;
      if (!sameApp) this.notice = null;
      else if (status === "inserted") this.notice = { tone: "ok", text: copy.inserted };
      else if (status === "nodoc") this.notice = { tone: "err", text: copy.noDocument };
      else this.notice = { tone: "err", text: copy.insertFailed };
      this.syncDock();
    }
    setQuery(value, immediate) {
      this.query = value;
      this.input.value = value;
      this.composing = false;
      this.syncClear();
      if (immediate) this.flushSearch();
      else this.scheduleSearch();
    }
    scheduleSearch() {
      window.clearTimeout(this.timer);
      if (!this.query.trim()) {
        this.clearResults();
        return;
      }
      this.render();
      this.timer = window.setTimeout(() => this.flushSearch(), DEBOUNCE_MS);
    }
    flushSearch() {
      window.clearTimeout(this.timer);
      const term = this.query.trim();
      if (!term) {
        this.clearResults();
        return;
      }
      this.submitted = term;
      this.status = "loading";
      this.requestId += 1;
      const requestId = this.requestId;
      send("search", { query: term, country: this.country, requestId });
      this.armWatchdog(requestId);
      this.render();
    }
    clearResults() {
      window.clearTimeout(this.timer);
      window.clearTimeout(this.watchdog);
      const shouldCancel = this.status === "loading" || this.submitted !== "";
      this.submitted = "";
      this.apps = [];
      this.status = "idle";
      this.selectedId = void 0;
      this.requestId += 1;
      if (shouldCancel) send("cancel");
      this.render();
    }
    armWatchdog(requestId) {
      window.clearTimeout(this.watchdog);
      this.watchdog = window.setTimeout(() => {
        if (this.requestId !== requestId || this.status !== "loading") return;
        this.apps = [];
        this.status = "error";
        this.selectedId = void 0;
        send("cancel");
        this.render();
      }, WATCHDOG_MS);
    }
    ensureSelection() {
      if (!this.apps.some((app) => app.trackId === this.selectedId)) this.selectedId = this.apps[0]?.trackId;
    }
    maybeRemember() {
      const term = this.submitted.trim();
      if (this.status !== "success" || this.apps.length === 0 || term.length < 2) return;
      const token = `${this.country}:${term}`;
      if (this.savedToken === token) return;
      this.savedToken = token;
      this.recent = rememberRecent(this.recent, term);
      this.recentTouched = true;
      send("setRecent", { recent: this.recent });
    }
    select(trackId) {
      this.selectedId = trackId;
      this.notice = null;
      this.render();
    }
    removeRecent(term) {
      this.recent = forgetRecent(this.recent, term);
      this.recentTouched = true;
      send("setRecent", { recent: this.recent });
      this.render();
    }
    insert(app) {
      if (this.busy) return;
      this.busy = true;
      this.notice = null;
      this.insertTrackId = app.trackId;
      this.syncDock();
      send("insert", { artworkUrl: app.artworkUrl, name: app.trackName });
    }
    render() {
      this.syncClear();
      const active = this.status === "loading" || this.isStale();
      this.progress.dataset.active = active ? "true" : "false";
      this.stage.setAttribute("aria-busy", active ? "true" : "false");
      this.renderStatus();
      this.renderStage();
      this.renderDock();
    }
    renderStatus() {
      const typed = this.query.trim();
      if (!typed) this.statusNode.textContent = "";
      else if (this.status === "loading" || this.isStale()) this.statusNode.textContent = copy.loading;
      else if (this.status === "error" && this.apps.length === 0) this.statusNode.textContent = copy.errorTitle;
      else if (this.apps.length === 0) this.statusNode.textContent = copy.noResults;
      else this.statusNode.textContent = copy.resultCount(this.apps.length);
    }
    syncClear() {
      this.clearButton.hidden = this.query.length === 0;
    }
    renderStage() {
      const key = `${this.stageMode()}|${this.recent.join("\n")}`;
      if (key !== this.stageKey) {
        this.stageKey = key;
        this.resultsNode = void 0;
        this.stage.replaceChildren();
        this.buildStage();
      }
      this.resultsNode?.classList.toggle("is-stale", this.apps.length > 0 && (this.isStale() || this.status === "loading"));
      this.syncSelection();
    }
    buildStage() {
      if (this.recent.length > 0) this.stage.append(this.recentRow());
      const mode = this.stageMode();
      if (mode === "idle") {
        this.stage.append(this.idleState());
        return;
      }
      if (mode === "error") {
        this.stage.append(this.messageState(copy.errorTitle, copy.errorHint, copy.retry, () => this.retry()));
        return;
      }
      if (mode === "loading") {
        this.stage.append(this.skeleton());
        return;
      }
      if (mode === "empty") {
        this.stage.append(this.messageState(copy.noResults, copy.noResultsHint));
        return;
      }
      this.stage.append(this.results());
    }
    stageMode() {
      if (!this.query.trim()) return "idle";
      if (this.apps.length === 0 && this.status === "error" && !this.isStale()) return "error";
      if (this.apps.length === 0 && (this.status === "loading" || this.isStale() || this.status === "idle")) return "loading";
      if (this.apps.length === 0) return "empty";
      return `results:${this.apps.map((app) => String(app.trackId)).join(",")}`;
    }
    retry() {
      if (this.submitted.trim()) this.flushSearch();
    }
    recentRow() {
      const row = el("div", "recent");
      const label = el("div", "recent-label");
      label.textContent = copy.recent;
      const chips = el("div", "chips");
      for (const term of this.recent) {
        const wrap = el("span", "chip-wrap");
        const chip = el("button", "chip");
        chip.type = "button";
        chip.textContent = term;
        chip.addEventListener("click", () => this.setQuery(term, true));
        const remove = el("button", "chip-x");
        remove.type = "button";
        remove.setAttribute("aria-label", `${copy.removeRecent} ${term}`);
        remove.textContent = "\xD7";
        remove.addEventListener("click", () => this.removeRecent(term));
        wrap.append(chip, remove);
        chips.append(wrap);
      }
      row.append(label, chips);
      return row;
    }
    idleState() {
      const block = el("div", "empty");
      const title = el("p", "empty-title");
      title.textContent = copy.idleTitle;
      const body = el("p", "empty-body");
      body.textContent = copy.idleBody;
      const chips = el("div", "chips");
      chips.setAttribute("aria-label", copy.suggestionsLabel);
      for (const term of copy.suggestions) {
        const chip = el("button", "chip chip-solid");
        chip.type = "button";
        chip.textContent = term;
        chip.addEventListener("click", () => this.setQuery(term, true));
        chips.append(chip);
      }
      block.append(title, body, chips);
      return block;
    }
    messageState(title, hint, action, onAction) {
      const block = el("div", "empty");
      const heading = el("p", "empty-title");
      heading.textContent = title;
      const body = el("p", "empty-body");
      body.textContent = hint;
      block.append(heading, body);
      if (action && onAction) {
        const button = el("button", "secondary");
        button.type = "button";
        button.textContent = action;
        button.addEventListener("click", onAction);
        block.append(button);
      }
      return block;
    }
    skeleton() {
      const grid = el("div", "grid");
      grid.setAttribute("aria-hidden", "true");
      for (let index = 0; index < 9; index += 1) grid.append(el("div", "skeleton"));
      return grid;
    }
    results() {
      const block = el("div", "results");
      const count = el("p", "count");
      count.textContent = copy.resultCount(this.apps.length);
      const grid = el("div", "grid");
      grid.setAttribute("role", "listbox");
      grid.setAttribute("aria-label", copy.resultsLabel);
      for (const app of this.apps) grid.append(this.tile(app));
      block.append(count, grid);
      this.resultsNode = block;
      return block;
    }
    tile(app) {
      const button = el("button", "tile");
      button.type = "button";
      button.dataset.result = "true";
      button.dataset.trackId = String(app.trackId);
      button.setAttribute("role", "option");
      button.setAttribute("aria-label", app.trackName);
      button.title = app.artistName ? `${app.trackName} \u2014 ${app.artistName}` : app.trackName;
      button.append(iconImage(app));
      button.addEventListener("click", () => this.select(app.trackId));
      return button;
    }
    syncSelection() {
      const selected = this.selectedId === void 0 ? "" : String(this.selectedId);
      for (const button of this.stage.querySelectorAll('[data-result="true"]')) {
        const pressed = button.dataset.trackId === selected;
        button.setAttribute("aria-pressed", pressed ? "true" : "false");
        button.setAttribute("aria-selected", pressed ? "true" : "false");
      }
    }
    renderDock() {
      const app = this.apps.find((item) => item.trackId === this.selectedId);
      if (!app) {
        this.dock.hidden = true;
        this.dock.replaceChildren();
        this.dockTrackId = void 0;
        this.dockButton = void 0;
        this.dockLabel = void 0;
        this.dockNotice = void 0;
        return;
      }
      this.dock.hidden = false;
      if (this.dockTrackId !== app.trackId) this.buildDock(app);
      this.syncDock();
    }
    buildDock(app) {
      this.dockTrackId = app.trackId;
      this.notice = null;
      this.dock.replaceChildren();
      this.dock.setAttribute("aria-label", copy.selectedLabel);
      const head = el("div", "dock-head");
      const thumb = el("div", "dock-thumb");
      thumb.append(iconImage(app));
      const meta = el("div", "dock-copy");
      const title = el("p", "dock-title");
      title.textContent = app.trackName;
      title.title = app.trackName;
      meta.append(title);
      if (app.artistName) {
        const artist = el("p", "dock-meta");
        artist.textContent = app.artistName;
        meta.append(artist);
      }
      if (app.primaryGenreName) {
        const genre = el("p", "dock-meta");
        genre.textContent = app.primaryGenreName;
        meta.append(genre);
      }
      head.append(thumb, meta);
      const button = el("button", "primary");
      button.type = "button";
      const label = el("span");
      button.append(label);
      button.addEventListener("click", () => this.insert(app));
      const rights = el("p", "rights");
      rights.textContent = copy.rights;
      const notice = el("p", "notice");
      notice.setAttribute("role", "status");
      this.dockButton = button;
      this.dockLabel = label;
      this.dockNotice = notice;
      this.dock.append(head, button, rights, notice);
    }
    syncDock() {
      if (!this.dockButton || !this.dockLabel || !this.dockNotice) return;
      this.dockButton.disabled = this.busy;
      this.dockLabel.textContent = this.busy ? copy.inserting : copy.insert;
      this.dockNotice.dataset.tone = this.notice?.tone ?? "idle";
      this.dockNotice.textContent = this.notice?.text ?? "";
    }
    isStale() {
      const typed = this.query.trim();
      return typed.length > 0 && typed !== this.submitted.trim();
    }
  };
  function send(type, payload) {
    if (payload === void 0) host.postMessage(type);
    else host.postMessage(type, payload);
  }
  function readRecord(value) {
    if (typeof value === "object" && value !== null) return value;
    return void 0;
  }
  function readApps(value) {
    if (!Array.isArray(value)) return [];
    const apps = [];
    for (const item of value) {
      if (!item || typeof item !== "object") continue;
      const row = item;
      const artwork = artworkUrl(row.artworkUrl);
      if (typeof row.trackId !== "number" || typeof row.trackName !== "string" || !artwork) continue;
      apps.push({
        trackId: row.trackId,
        trackName: row.trackName.slice(0, 300),
        artistName: typeof row.artistName === "string" ? row.artistName.slice(0, 300) : "",
        artworkUrl: artwork,
        primaryGenreName: typeof row.primaryGenreName === "string" ? row.primaryGenreName.slice(0, 80) : void 0
      });
    }
    return apps;
  }
  function readInsertStatus(value) {
    if (value === "inserted" || value === "nodoc" || value === "failed") return value;
    return "failed";
  }
  function iconImage(app) {
    const image = document.createElement("img");
    image.src = app.artworkUrl;
    image.alt = "";
    image.width = 512;
    image.height = 512;
    image.decoding = "async";
    image.draggable = false;
    image.addEventListener("error", () => image.replaceWith(fallback(app.trackName)));
    return image;
  }
  function fallback(name) {
    const node = el("span", "thumb-fallback");
    node.setAttribute("aria-hidden", "true");
    node.textContent = name.trim().charAt(0).toUpperCase() || "?";
    return node;
  }
  function required(ctor, id) {
    const node = document.getElementById(id);
    if (!(node instanceof ctor)) throw new Error(`Missing #${id}`);
    return node;
  }
  function text(id, value) {
    const node = document.getElementById(id);
    if (node) node.textContent = value;
  }
  function el(tag, className) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    return node;
  }
  new AppView();
})();
